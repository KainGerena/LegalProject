// config/database.js
module.exports = {

    'url'=mongodb://legalprojectadmin:l46jVZH0QR6mgpA9@cluster0-shard-00-00-0gyzs.mongodb.net:27017,cluster0-shard-00-01-0gyzs.mongodb.net:27017,cluster0-shard-00-02-0gyzs.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin

};

// Data stub to used for testing.
// This will be changed when a database is setup

var survey_data =
[

];

module.exports = survey_data;

// Data stub to used for testing.
// This will be changed when a database is setup

var users_data = 
[
  	{name: 'Frodo', lastname: 'Baggins'}, 
  	{name: 'Sam', lastname: 'Gamgee'},
  	{name: 'Peregrin', lastname: 'Took'} 
];

module.exports = users_data;

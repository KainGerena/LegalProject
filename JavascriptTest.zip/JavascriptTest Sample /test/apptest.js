//unit test for the code in app.js 

const assert = require('chai').assert; 

const matvec = require('../app'); 

describe('MatVec', function () {

	it('adding pos vectors', function(){
		let v = [1, 1, 1, 1]; 
		let w = [3, 3, 3, 3]; 
		//running the addVec() function in app.js 
		let result = matvec.addVec(v, w); 
		assert.deepEqual(result, [4, 4, 4, 4]); 


	}); 

	it('adding vectors with neg entries', function(){
		let v = [0, -1, -10, 1]; 
		let w = [3, 3, 3, 3]; 
		//running the addVec() function in app.js 
		let result = matvec.addVec(v, w); 
		assert.deepEqual(result, [3, 2, -7, 4]); 


	}); 

	it('dot product using vector', function(){
		let v = [1, 1, 1, 1]; 
		let w = [2, 2, 2, 2]; 
		let result = matvec.dotProduct(v,w); 
		assert.deepEqual(result, 8); 
	}); 

}); 

